<!doctype html>
<html>

<meta charset="ISO-8859-1">


<style>
body{
  font-family: Arial;
  font-size: 13px;
}
</style>
<body>
<blockquote>
<blockquote>
   <center>
    <br>
    <h1> COMUNICADO </h1>
    <br><br>

    <p align="justify">
    Se comunica a los señores Docentes y Tesistas usuarios de las diversas Plataformas
    del Vicerrectorado de Investigacion que hemos iniciado un proceso de migración con 
    la finalidad de evitar caidas a futuro, debido a las deficiencias tecnicas con el actual
    proveedor de nuestro VPS (Virtual Private Server), rogamos su comprensión y en los términos
    técnicos posibles levantaremos las diversas plataformas y poder brindar los servicios a nuestros usuarios.
    Agregar ademas que los plazos de los tramites de proyectos y borradores se congelan y se brindara
    las facilidades necesarias excepto los que ya se vencieron antes del 10 de agosto del presente.
    </p>

    <br><br>
   Vicerrectorado de Investigación <br>
   Universidad Nacional del Altiplano
   </center>
</blockquote>
</blockquote>
<body>
</html>


