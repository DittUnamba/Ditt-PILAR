<?PHP  if ( ! defined('LX_COREDIR')) exit('There is no Lightning-X Core');
//------------------------------------------------------------------------------

use LxCore\LxController;
use LxCore\LxTable;
use LxCore\Ado;


class Web extends LxController{

    public function __construct()
    {
        parent:: __construct();

        /*
        $this->Model( "Ado" );

        $this->Library( "RemDB" );
        $this->Library( "email" );
        $this->Library( "BS" );
        $this->Library( "GenApi" );

        $this->Library( "SexyPdf" );
        */
    }

    public function Run()
    {
        echo "raiz Web::Index() ";

        $this->Library( "BS" );
        //$this->BS->Index();
    }
    
    public function Index()
    {
        $this->View( "comuni" );
    }
}

?>