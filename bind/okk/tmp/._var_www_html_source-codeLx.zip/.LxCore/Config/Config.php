<?php
// server start point
//
$config["BASE_URL"] = "http://escueladearte.edu.pe/";


// start controller
//
$config["Start"] = "Web";


// local routes
//
//$routes["/demo"] = "web/index";


// also in Router.php
//   $route->Add( "/demo", "demo/config.php" );
//   $route->Post( "/demo", function(){  } );

?>