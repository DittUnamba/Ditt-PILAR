<?php
/************************************************************************
*  Lightning XR - 2024
*  Dockable design 4S
*
*  Designed by: Ramiro Pedro Laura Murillo
*               Doctor in Computer Science
*               Master Degree in Informatics
*               Universidad Nacional del Altiplano
*
*  Module : LxApp Invoker
*  Native : php7.2+  compiled in  7.4+ - 8.2+
*
************************************************************************/



use LxCore\LxRoutes;


$router->Add( "/demox", "web/index" );