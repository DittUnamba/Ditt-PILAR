Libraries from Third developers
all folders and includes made in
Library/ adding this lines

include_once( LX_EXTRADIR . "/fpdf/fpdf.php" );