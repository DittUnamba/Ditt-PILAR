@if( false )
    <img src= "{{ asset('img/logon.png') }}" >
@else
    <div>
        Area de else <i>Probando...</i>
    </div>
@end
