<?php if( false ):  ?>
    <img src= "<?php echo  asset('img/logon.png') ; ?>" >
<?php else:  ?>
    <div>
        Area de else <i>Probando...</i>
    </div>
<?php endif;  ?>
